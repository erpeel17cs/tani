# PetaniHub - Toko Online & Marketplace Petani

Website statis toko online untuk para petani dengan fitur lengkap:
- **Authentication**: Login & Register (Multi-role: Petani & Pembeli).
- **CRUD Produk Tani**: Tambah, Edit, Hapus, dan Kelola Stok Hasil Tani.
- **Katalog & Filter**: Pencarian interaktif & filter berdasarkan kategori.
- **Keranjang Belanja & Payment**: Cart management, simulasi checkout, opsi payment gateway, & invoice pembayaran.

## Cara Menggunakan
1. Ekstrak file `petanihub-website.zip`.
2. Buka file `index.html` langsung di browser web Anda (Chrome, Firefox, Edge, dll.).
3. Tidak memerlukan server backend khusus (siap dijalankan langsung atau di-host di GitHub Pages/Netlify/Vercel).
